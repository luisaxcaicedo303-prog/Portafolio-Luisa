import { useState, useRef, useEffect } from 'react';
import { useDarkMode } from '../../contexts/DarkModeContext';
import { useThemeColors } from '../../hooks/useThemeColors';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '../ui/tooltip';
import { ExternalLink, Heart, ChevronLeft, ChevronRight } from 'lucide-react';
import { lightStars, darkStars, specialStars } from '../../assets/stars';
import { techStackIcons } from '../../assets/techstack';

const projects = [
  {
    title: 'Examen n8n',
    description: 'Proyecto de automatización y gestión de exámenes desarrollado durante mi formación.',
    technologies: ['n8n', 'HTML', 'JavaScript'],
    icon: techStackIcons.JavaScript,
    githubUrl: 'https://github.com/luisaxcaicedo303-prog/examen_n8n'
  },
  {
    title: 'Sistema de Reclutamiento con IA',
    description: 'Plataforma para apoyar la preselección y evaluación técnica de candidatos mediante automatización e inteligencia artificial.',
    technologies: ['JavaScript', 'HTML', 'PostgreSQL', 'IA'],
    icon: techStackIcons.JavaScript,
    githubUrl: 'https://github.com/luisaxcaicedo303-prog/sistema-reclutamiento-ia'
  },
  {
    title: 'Automatización de Droguería',
    description: 'Solución orientada a automatizar procesos de gestión y operación de una droguería.',
    technologies: ['HTML', 'CSS', 'JavaScript'],
    icon: techStackIcons.HTML,
    githubUrl: 'https://github.com/luisaxcaicedo303-prog/Automatizacion_drogueria'
  },
  {
    title: 'CostEstimator',
    description: 'Proyecto web para estimación de costos, desarrollado como parte de mi proceso de aprendizaje y construcción de interfaces.',
    technologies: ['HTML', 'CSS'],
    icon: techStackIcons.CSS,
    githubUrl: 'https://github.com/luisaxcaicedo303-prog/CostEstimator'
  }
];

const Projects = () => {
  const { isDarkMode } = useDarkMode();
  const themeColors = useThemeColors();

  const [stars, setStars] = useState<Array<{ id: number; x: number; y: number; image: string; isDragging: boolean }>>([]);
  const [draggedStar, setDraggedStar] = useState<number | null>(null);
  const [specialStar, setSpecialStar] = useState<{ x: number; y: number }>({ x: 85, y: 8 });
  const [isDraggingSpecial, setIsDraggingSpecial] = useState(false);
  const [currentPage, setCurrentPage] = useState(0);
  const [direction, setDirection] = useState<'left' | 'right'>('right');
  const projectsPerPage = 4;
  const containerRef = useRef<HTMLDivElement>(null);
  const isDraggingRef = useRef(false);

  useEffect(() => {
    const generatedStars = Array.from({ length: 30 }, (_, i) => {
      let x: number;
      let y: number;
      const zone = i % 4;
      if (zone === 0) {
        x = Math.random() * 90 + 5;
        y = Math.random() * 10;
      } else if (zone === 1) {
        x = Math.random() * 90 + 5;
        y = Math.random() * 10 + 90;
      } else if (zone === 2) {
        x = Math.random() * 15;
        y = Math.random() * 60 + 20;
      } else {
        x = Math.random() * 15 + 85;
        y = Math.random() * 60 + 20;
      }

      const availableStars = isDarkMode ? darkStars : lightStars;
      return {
        id: i,
        x,
        y,
        image: availableStars[Math.floor(Math.random() * availableStars.length)],
        isDragging: false
      };
    });
    setStars(generatedStars);
  }, [isDarkMode]);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (isDraggingSpecial && containerRef.current) {
        const rect = containerRef.current.getBoundingClientRect();
        setSpecialStar({
          x: Math.max(0, Math.min(95, ((e.clientX - rect.left) / rect.width) * 100)),
          y: Math.max(0, Math.min(95, ((e.clientY - rect.top) / rect.height) * 100))
        });
      }
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (isDraggingSpecial && containerRef.current && e.touches.length > 0) {
        const rect = containerRef.current.getBoundingClientRect();
        const touch = e.touches[0];
        setSpecialStar({
          x: Math.max(0, Math.min(95, ((touch.clientX - rect.left) / rect.width) * 100)),
          y: Math.max(0, Math.min(95, ((touch.clientY - rect.top) / rect.height) * 100))
        });
      }
    };

    const stopDragging = () => {
      setIsDraggingSpecial(false);
      isDraggingRef.current = false;
    };

    if (isDraggingSpecial) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', stopDragging);
      document.addEventListener('touchmove', handleTouchMove);
      document.addEventListener('touchend', stopDragging);
    }

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', stopDragging);
      document.removeEventListener('touchmove', handleTouchMove);
      document.removeEventListener('touchend', stopDragging);
    };
  }, [isDraggingSpecial]);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (draggedStar !== null && containerRef.current) {
        const rect = containerRef.current.getBoundingClientRect();
        const x = Math.max(0, Math.min(95, ((e.clientX - rect.left) / rect.width) * 100));
        const y = Math.max(0, Math.min(95, ((e.clientY - rect.top) / rect.height) * 100));
        setStars(prev => prev.map(star => star.id === draggedStar ? { ...star, x, y } : star));
      }
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (draggedStar !== null && containerRef.current && e.touches.length > 0) {
        const rect = containerRef.current.getBoundingClientRect();
        const touch = e.touches[0];
        const x = Math.max(0, Math.min(95, ((touch.clientX - rect.left) / rect.width) * 100));
        const y = Math.max(0, Math.min(95, ((touch.clientY - rect.top) / rect.height) * 100));
        setStars(prev => prev.map(star => star.id === draggedStar ? { ...star, x, y } : star));
      }
    };

    const stopDragging = () => {
      if (draggedStar !== null) {
        setStars(prev => prev.map(star => star.id === draggedStar ? { ...star, isDragging: false } : star));
        setDraggedStar(null);
        isDraggingRef.current = false;
      }
    };

    if (draggedStar !== null) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', stopDragging);
      document.addEventListener('touchmove', handleTouchMove);
      document.addEventListener('touchend', stopDragging);
    }

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', stopDragging);
      document.removeEventListener('touchmove', handleTouchMove);
      document.removeEventListener('touchend', stopDragging);
    };
  }, [draggedStar]);

  const totalPages = Math.ceil(projects.length / projectsPerPage);
  const startIndex = currentPage * projectsPerPage;
  const currentProjects = projects.slice(startIndex, startIndex + projectsPerPage);

  const handlePrevPage = () => {
    if (currentPage > 0) {
      setDirection('left');
      setCurrentPage(prev => prev - 1);
    }
  };

  const handleNextPage = () => {
    if (currentPage < totalPages - 1) {
      setDirection('right');
      setCurrentPage(prev => prev + 1);
    }
  };

  return (
    <section
      id="projects"
      className="py-20 relative transition-colors duration-300"
      style={{
        background: themeColors.background.sections?.projects || themeColors.background.gradient,
        transition: 'background 0.3s ease-in-out'
      }}
      ref={containerRef}
    >
      <div className="absolute top-0 left-0 right-0 pointer-events-none" style={{
        height: '150px',
        background: isDarkMode
          ? `linear-gradient(180deg, ${themeColors.background.gradientEnd} 0%, transparent 100%)`
          : `linear-gradient(180deg, ${themeColors.colors.pink[25]} 0%, transparent 100%)`,
        zIndex: 2
      }} />

      <div
        className="special-draggable-star"
        onMouseDown={(e) => {
          e.stopPropagation();
          setIsDraggingSpecial(true);
          isDraggingRef.current = true;
        }}
        onTouchStart={(e) => {
          e.stopPropagation();
          setIsDraggingSpecial(true);
          isDraggingRef.current = true;
        }}
        style={{
          position: 'absolute',
          left: `${specialStar.x}%`,
          top: `${specialStar.y}%`,
          width: '44px',
          height: '44px',
          zIndex: 15,
          cursor: isDraggingSpecial ? 'grabbing' : 'grab',
          userSelect: 'none',
          animation: 'twinkle 3s infinite'
        }}
      >
        <img
          src={isDarkMode ? specialStars.dragMeStarDark : specialStars.dragMeStar}
          alt="Estrella para mover"
          style={{ width: '100%', height: '100%', pointerEvents: 'none' }}
          draggable={false}
          loading="lazy"
          width="44"
          height="44"
        />
      </div>

      <div style={{
        position: 'absolute', left: '85%', top: '5%', zIndex: 16,
        display: 'flex', alignItems: 'center', gap: '8px', pointerEvents: 'none'
      }}>
        <img
          src={isDarkMode ? specialStars.arrowDark : specialStars.arrow}
          alt="Flecha"
          style={{ width: '45px', height: '45px', marginLeft: '40px' }}
          draggable={false}
          loading="lazy"
        />
        <span style={{
          fontFamily: "'DK Crayonista', cursive",
          fontSize: '26px',
          color: isDarkMode ? '#FDD5DF' : '#ec4899',
          fontWeight: 'bold',
          userSelect: 'none',
          textShadow: '1px 1px 2px rgba(0,0,0,0.1)'
        }}>
          ¡muéveme!
        </span>
      </div>

      {stars.map(star => (
        <div
          key={star.id}
          className="draggable-star"
          onMouseDown={(e) => {
            e.stopPropagation();
            setDraggedStar(star.id);
            isDraggingRef.current = true;
            setStars(prev => prev.map(item => item.id === star.id ? { ...item, isDragging: true } : item));
          }}
          onTouchStart={(e) => {
            e.stopPropagation();
            setDraggedStar(star.id);
            isDraggingRef.current = true;
            setStars(prev => prev.map(item => item.id === star.id ? { ...item, isDragging: true } : item));
          }}
          style={{
            position: 'absolute', left: `${star.x}%`, top: `${star.y}%`, width: '50px', height: '50px',
            zIndex: 1, cursor: star.isDragging ? 'grabbing' : 'grab', userSelect: 'none'
          }}
        >
          <img src={star.image} alt="Estrella" style={{ width: '100%', height: '100%', pointerEvents: 'none' }} draggable={false} loading="lazy" width="50" height="50" />
        </div>
      ))}

      <TooltipProvider delayDuration={200}>
        <div className="container mx-auto px-6 relative z-10">
          <div className="flex items-center justify-center gap-1 mb-4">
            <h2 className="text-4xl font-bold" style={{ color: isDarkMode ? themeColors.colors.white : themeColors.colors.pink[500] }}>
              Proyectos
            </h2>
            <Tooltip>
              <TooltipTrigger asChild>
                <button
                  className="inline-flex items-center justify-center bg-transparent border-none outline-none focus:outline-none"
                  style={{ minWidth: '44px', minHeight: '44px' }}
                  aria-label="Información sobre los iconos de proyectos"
                >
                  <Heart className="h-5 w-5 cursor-pointer transition-colors" style={{ color: themeColors.primary }} fill="none" />
                </button>
              </TooltipTrigger>
              <TooltipContent className="bg-white text-gray-800 border-pink-200">
                <p>Todos los proyectos enlazan a mi GitHub.</p>
              </TooltipContent>
            </Tooltip>
          </div>

          <p className="text-center mb-12 text-lg text-gray-600 dark:text-gray-300">
            Una selección de proyectos que he desarrollado durante mi formación y proceso de aprendizaje.
          </p>

          <div
            key={currentPage}
            className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-6xl mx-auto mb-8"
            style={{ animation: `slideIn${direction === 'right' ? 'Right' : 'Left'} 0.4s ease-out` }}
          >
            {currentProjects.map(project => (
              <Card key={project.title} className="group hover:shadow-lg transition-all duration-300 hover:-translate-y-1 relative" style={{
                backgroundColor: themeColors.card.background,
                border: `1px solid ${themeColors.card.border}`
              }} aria-label={`Proyecto ${project.title}`}>
                <CardHeader>
                  <div className="flex items-start gap-3">
                    <img src={project.icon} alt={`Icono de ${project.title}`} className="w-12 h-12 rounded-lg object-contain p-1 bg-white/70" loading="lazy" width="48" height="48" />
                    <div className="flex-1">
                      <CardTitle className="text-xl dark:text-gray-100 transition-colors group-hover:!text-pink-500 dark:group-hover:!text-pink-400">
                        {project.title}
                      </CardTitle>
                      <CardDescription className="text-gray-600 dark:text-gray-300 mt-2">
                        {project.description}
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent style={{ display: 'flex', flexDirection: 'column' }}>
                  <div className="flex flex-wrap gap-2 mb-4" style={{ flex: '1 0 auto' }}>
                    {project.technologies.map(tech => (
                      <Badge key={tech} variant="secondary" className="text-xs" style={{
                        backgroundColor: themeColors.interactive.primary,
                        color: themeColors.text.accent,
                        borderColor: themeColors.primary,
                        border: '1px solid'
                      }}>
                        {tech}
                      </Badge>
                    ))}
                  </div>
                  <div className="flex gap-3" style={{ marginTop: 'auto', paddingTop: '8px' }}>
                    <a
                      href={project.githubUrl}
                      className="project-btn flex items-center gap-1"
                      style={{ textDecoration: 'none', color: 'white' }}
                      target="_blank"
                      rel="noopener noreferrer"
                      aria-label={`Ver ${project.title} en GitHub`}
                    >
                      <ExternalLink className="h-4 w-4" aria-hidden="true" />
                      Ver proyecto
                    </a>
                    <a
                      href={project.githubUrl}
                      className="project-btn-outline flex items-center gap-1"
                      style={{ textDecoration: 'none' }}
                      target="_blank"
                      rel="noopener noreferrer"
                      aria-label={`Ver el código de ${project.title} en GitHub`}
                    >
                      Código
                    </a>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {totalPages > 1 && (
            <div className="flex items-center justify-center gap-3 mt-4 relative z-10" style={{ minHeight: '32px' }}>
              <button onClick={handlePrevPage} disabled={currentPage === 0} className="transition-all duration-200 hover:scale-110" style={{
                color: isDarkMode ? themeColors.colors.pink[300] : themeColors.colors.pink[400],
                opacity: currentPage === 0 ? 0.2 : 0.6,
                cursor: currentPage === 0 ? 'not-allowed' : 'pointer',
                background: 'none', border: 'none', padding: '4px', minWidth: '28px', minHeight: '28px',
                display: 'flex', alignItems: 'center', justifyContent: 'center'
              }} aria-label="Proyectos anteriores">
                <ChevronLeft className="h-5 w-5" />
              </button>
              <div className="flex gap-2">
                {Array.from({ length: totalPages }, (_, i) => (
                  <button key={i} onClick={() => {
                    if (i !== currentPage) {
                      setDirection(i > currentPage ? 'right' : 'left');
                      setCurrentPage(i);
                    }
                  }} className="transition-all duration-200" style={{
                    width: currentPage === i ? '24px' : '8px', height: '8px', borderRadius: '4px',
                    backgroundColor: isDarkMode ? themeColors.colors.pink[300] : themeColors.colors.pink[400],
                    opacity: currentPage === i ? 1 : 0.3, cursor: 'pointer', border: 'none', padding: 0
                  }} aria-label={`Ir a la página ${i + 1}`} />
                ))}
              </div>
              <button onClick={handleNextPage} disabled={currentPage === totalPages - 1} className="transition-all duration-200 hover:scale-110" style={{
                color: isDarkMode ? themeColors.colors.pink[300] : themeColors.colors.pink[400],
                opacity: currentPage === totalPages - 1 ? 0.2 : 0.6,
                cursor: currentPage === totalPages - 1 ? 'not-allowed' : 'pointer',
                background: 'none', border: 'none', padding: '4px', minWidth: '28px', minHeight: '28px',
                display: 'flex', alignItems: 'center', justifyContent: 'center'
              }} aria-label="Proyectos siguientes">
                <ChevronRight className="h-5 w-5" />
              </button>
            </div>
          )}
        </div>
      </TooltipProvider>

      <div className="absolute bottom-0 left-0 right-0 pointer-events-none" style={{
        height: '150px',
        background: isDarkMode
          ? `linear-gradient(180deg, transparent 0%, ${themeColors.background.gradientEnd} 100%)`
          : `linear-gradient(180deg, transparent 0%, ${themeColors.colors.pink[25]} 100%)`,
        zIndex: 1
      }} />
    </section>
  );
};

export default Projects;
